#Imports do FastAPI
from fastapi import APIRouter, Form, UploadFile, File, status, Depends, HTTPException, Header
from fastapi.responses import StreamingResponse
from typing import List

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select

from core.deps import get_session

from models.files_models import StoredFile



#Criação do router
router = APIRouter()

#Criação do endpoint
@router.post("/")
async def create_upload_file(file: UploadFile = File(...)): #Parametro de cabeçalho
    #Retornando o nome do arquivo
    return {"Filename": file.filename}


#Salvar o arquivo dentro de diretorios locais, no caso uploads
@router.post("/savefile/")
async def save_upload_file(file: UploadFile = File(...)):
    #Abre (ou cria) um arquvio binario em um diretorio local
    #wb = significa workbook, pasta 
    with open(f'api/v1/endpoints/uploads/{file.filename}', "wb") as f:
        f.write(file.file.read())
    return{"message": f"File '{file.filename}' saved successfully"}


#Upload de multiplos arquivos do mesmo tempo, como uma lista
#Irei usar uma lista para fazer
@router.post("/multiplefiles")
async def multiple_files(files: List[UploadFile] = File(...)):
    return {"filenames": [file.filename for file in files]}


#Salvar arquivo no banco
@router.post("/upload_db")
async def upload_file_to_bd(file: UploadFile = File(...), db: AsyncSession = Depends(get_session)):
    try:
        #Vai jogar nessa variavel
        content = await file.read()
        
        novo_file = StoredFile(
            filename=file.filename,
            content_type=file.content_type,
            content=content
        )
        #Adiciona no banco o arquivo a confirma no banco
        db.add(novo_file)
        await db.commit()
        
        #Atualiza o banco com o novo arquivo
        await db.refresh(novo_file)
        return{
            "id" : novo_file.id,
            "filename" : novo_file.filename,
            "content_type" : novo_file.content_type
        }
        
    #Cria a exceção
    except Exception as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
    

#Endpoint de baixar aquilo que mandamos para o banco
@router.get("/download/{file_name}")
async def download_file(file_id: int, db: AsyncSession = Depends(get_session)):
    try:
        #Cria uma query para buscar o arquivo pelo ID
        query = select(StoredFile).filter(StoredFile.id == file_id)
        result = await db.execute(query)
        stored_file = result.scalar_one_or_none()
        
        #Se não encontrar o arquivo, retorna 404
        if not  stored_file:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, 
                                detail="Arquivo não encontrado")
        
        #Envia o  bytes
        async def file_iterator(data: bytes):
            yield data
            
        #Retorna o arquivo como resposta de streaming (download)
        return StreamingResponse(
            file_iterator(stored_file.content), #Fluxo de bytes
            media_type=stored_file.content_type, # Tipo mime original
            headers={
                #Indica ao navegador que o conteudo é para download
                "Content-Disposition" : f"attachment; filename={stored_file.filename}"
            }
        )
    except Exception as e:
        #Captura erros genericos e retorna HTTP 500
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, 
                            detail=f"Erro ao fazer download: {e}")
        
        
