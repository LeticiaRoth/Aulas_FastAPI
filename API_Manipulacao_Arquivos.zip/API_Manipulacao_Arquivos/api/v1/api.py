from fastapi import APIRouter

#Meus endpoints
from api.v1.endpoints import curso, files

api_router = APIRouter()

api_router.include_router(curso.router, prefix="/cursos", tags=["cursos"])

#Criação da rota do Files para ele encontrar o meu files
api_router.include_router(files.router, prefix="/files", tags=["Files"])



